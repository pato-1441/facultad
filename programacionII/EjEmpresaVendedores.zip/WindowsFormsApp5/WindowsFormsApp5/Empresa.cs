﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp5 {
	internal class Empresa {
		int cantVendedores;
		List<Vendedor> vendedores = new List<Vendedor>();

		public List<Vendedor> Vendedores { get { return vendedores;} }

		public void AgregarVendedor(Vendedor vendedor) {
			vendedores.Add(vendedor);
			cantVendedores++;
		}

		public Empresa() {
			cantVendedores = 0;
		}

		public void AgregarVenta(double monto, int codigoVendedor) {
			Vendedor vendedor = BuscarVendedor(codigoVendedor);
			if(vendedor != null) {
				vendedor.AgregarVenta(monto);
			}
		}

		public double VerSueldo(int codigoVendedor) {
			double sueldo = 0;
			Vendedor vendedor = BuscarVendedor(codigoVendedor);
			if(vendedor != null) {
				sueldo = vendedor.Sueldo();
			}
			return sueldo;
		}

		/*public string[,] Sueldos() {
			string sueldos;
			return sueldos;
		}*/

		public Vendedor BuscarVendedor(int codigoVendedor) {
			Vendedor vendedor = null;
			int limiteInf = 0;
			int limiteSup = vendedores.Count - 1;			
			vendedores.Sort();
			
			while ( limiteInf <= limiteSup ) {

				int limiteMedio = (limiteInf+limiteSup) / 2;

				if (vendedores[limiteMedio].GetCodigo() == codigoVendedor) {

					return vendedores[limiteMedio];

				} else if (vendedores[limiteMedio].GetCodigo() > codigoVendedor) {

					limiteSup = limiteMedio - 1;

				} else {

					limiteInf = limiteMedio + 1;
				}
			}

			return vendedor;
		}
	}
}
